Nesse post você **pode salvar o arquivo README.md e edita-lo em seu computador** ou dispositivo, de acordo com o seu objetivo ou video que queira publicar, isso é, o "seu conteúdo" que julga interessante.

Nesse arquivo contem toda a demonstração das funções ja preenchidas no arquivo, logo, o trabalho será apenas compreender o video... obter o codigo do video... e subistitui-lo nos links do tutorial.

Talvez agregar conteudos como links externos para produtos ou ferramentas... caso não preciso disso, basta remover.

Imagens de destaque, que você pode anexar ao conteúdo também é possível.

Por fim, links direto a momentos importantes no video do youtube que esta se referenciado.

---

# Aqui fica o título do seu tutorial.

- Titulo do video 1
<p align="center">
  <a href="https://youtube.com/watch?v=wDchsz8nmbo" target="_blank" rel="noopener noreferrer">
    <img src="https://i.ytimg.com/vi/wDchsz8nmbo/maxresdefault.jpg">
  </a>
</p>

- Titulo do video 2
<p align="center">
  <a href="https://youtube.com/watch?v=krDWc30PAGg" target="_blank" rel="noopener noreferrer">
    <img src="https://i.ytimg.com/vi/krDWc30PAGg/maxresdefault.jpg">
  </a>
</p>

- Titulo do video 3
<p align="center">
  <a href="https://youtube.com/watch?v=a3ICNMQW7Ok" target="_blank" rel="noopener noreferrer">
    <img src="https://i.ytimg.com/vi/a3ICNMQW7Ok/maxresdefault.jpg">
  </a>
</p>

## 🌟 Objetivo / O que você vai aprender

Aqui fica uma descrição, objetivo, o que o usuário vai aprender com esse conteúdo.

## 🧰 Pré-requisitos

Lista de Componentes mostrados no vídeo ------------------------------------------------

- Produto 1: https://pt.aliexpress.com/item/100500
- Produto 2: https://pt.aliexpress.com/item/100500
- Produto 3: https://pt.aliexpress.com/item/100500

Ferramentas:
- Ferramenta 1: https://pt.aliexpress.com/item/100500
- Ferramenta 2: https://pt.aliexpress.com/item/100500
- Ferramenta 3: https://pt.aliexpress.com/item/100500

## ⏱️ Imagens ou Prints importantes do vídeo/tutorial

![Descrição da imagem](1.png)

![Descrição da imagem](2.jpg)


## ⏱️ Momentos importantes do vídeo

<ul>
  <li>
    <strong>
    <a href="https://www.youtube.com/watch?v=wDchsz8nmbo&t=0s" target="_blank" rel="noopener noreferrer">
      00:00 – Intro</strong>
    </a><br>
  </li>

  <li>
    <strong>
    <a href="https://www.youtube.com/watch?v=wDchsz8nmbo&t=35s" target="_blank" rel="noopener noreferrer">
      00:35 – Ceu estrelado</strong>
    </a><br>
  </li>

  <li>
    <strong>
    <a href="https://www.youtube.com/watch?v=krDWc30PAGg&t=28s" target="_blank" rel="noopener noreferrer">
      00:28 – Esmeralda</strong>
    </a><br>
  </li>


  <li>
    <strong>
    <a href="https://www.youtube.com/watch?v=a3ICNMQW7Ok&t=21s" target="_blank" rel="noopener noreferrer">
      00:21 – Koala</strong>
    </a><br>
  </li>
</ul>

**EM CONSTRUÇÃO**  